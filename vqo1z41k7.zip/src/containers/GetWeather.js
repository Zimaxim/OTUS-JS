import { connect } from 'react-redux'
import { getWeather } from '../actions'
import Context from '../components/Context'

const mapStateToProps = (state, ownProps) => {
  console.log("GetWeather.js::mapStateToProps::ownProps", ownProps );
  return {
    zip: ownProps.zip
  }
}

const mapDispatchToProps = (dispatch, ownProps) => {
  return {
    // onClick: () => {
    //   dispatch(setVisibilityFilter(ownProps.filter))
    // }
  }
}

const GetWeather = connect(
  mapStateToProps,
  mapDispatchToProps
)(Context)

export default GetWeather