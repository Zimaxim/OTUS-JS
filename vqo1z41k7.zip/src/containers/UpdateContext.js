import { connect } from 'react-redux'
//import { toggleTodo } from '../actions'
import Context from '../components/Context'

const getVisibleLocations = (locations, filter) => {
  switch (filter) {
    case 'SHOW_ALL':
      return locations
    case 'SHOW_COMPLETED':
      return locations.filter(t => t.completed)
    case 'SHOW_ACTIVE':
      return locations.filter(t => !t.completed)
  }
}

const mapStateToProps = (state) => {
  console.log("containers/UpdateContext.js :: getState()=", state);

  return {
    locations: getVisibleLocations(state.locations, state.visibilityFilter)
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    onLocationClick: (id) => {
      dispatch(toggleTodo(id))
    }
  }
}

const UpdateContext = connect(
  mapStateToProps,
  mapDispatchToProps
)(Context)

export default UpdateContext;