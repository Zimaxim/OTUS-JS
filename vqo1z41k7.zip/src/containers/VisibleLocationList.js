import { connect } from "react-redux";
//import { toggleTodo } from '../actions'
import LocationList from "../components/LocationList";

const getVisibleLocations = (state, filter) => {
  console.log(
    "containers/VisibleLocationList.js :: getVisibleLocations: =",
    state,
    filter
  );
  switch (filter) {
    case "SHOW_ALL":
      return state.locations;
    case "SHOW_FOUND":
      return state.locations.filter(
        t => (" "+t.zip).indexOf(state.searchActions.search) > -1
      );
    case "SHOW_ACTIVE":
      return state.locations.filter(t => !t.completed);
    default:
      return state.locations;
  }
};

const mapStateToProps = state => {
  console.log("containers/VisibleLocationList.js :: state=", state, "getVisibleLocations = ", getVisibleLocations(state.locations, state.visibilityFilter));
  //state.searchActions.search
  const searchActived = (state.searchActions.search);
  console.log(
    "containers/VisibleLocationList.js :: searchActived=",
    searchActived
  );

  return {
    locations: getVisibleLocations(
      state,
      searchActived === "" ? "SHOW_ALL" : "SHOW_FOUND" 
    )
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onLocationClick: id => {
      dispatch(toggleTodo(id));
    }
  };
};

const VisibleLocationList = connect(mapStateToProps, mapDispatchToProps)(
  LocationList
);

export default VisibleLocationList;
