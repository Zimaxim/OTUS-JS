import React, { Component } from "react";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

import SearchBar from "../components/SearchBar";
import { setSearch } from "../actions"

function mapStateToProps(state) {
   console.log("containers/SearchBar.js:: store.getState()",
  //   "setSearch=",setSearch, 
      "state=", state);
  return {
    //user: state
    visibilityFilter: "SET_SEARCH_STRING",
    search: state.search
  };
}

function mapDispatchToProps(dispatch) {
  return {
    setSearch: bindActionCreators(setSearch, dispatch)
    //searchActions: bindActionCreators(searchActions, dispatch)

  };
}

export default connect(mapStateToProps, mapDispatchToProps)(SearchBar);
