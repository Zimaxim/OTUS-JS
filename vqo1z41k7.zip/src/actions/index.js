import axios from "axios";

/*
 * типы действий
 */

export const ADD_LOC = "ADD_LOC";
export const CHECKED_LOCATION = "CHECKED_LOCATION";
export const SET_VISIBILITY_FILTER = "SET_VISIBILITY_FILTER";

/*
 * другие константы
 */

export const VisibilityFilters = {
  SHOW_ALL: "SHOW_ALL",
  SHOW_FOUND: "SHOW_FOUND",
  SET_SEARCH_STRING: "SET_SEARCH_STRING" 

};

/*
 * генераторы действий
 */

let nextLocationId = 10;

export const addLocation = zip => {
  return {
    type: "ADD_LOC",
    id: nextLocationId++,
    zip
  };
};

export const setFilter = search => {
  return {
    type: "SET_FILTER",
    search
  };
};

export const checkedLocation = place => {
  return {
    type: "CHECKED_LOCATION",
    place
  };
};

export const getWeather = zip => {
  return {
    type: "GET_WEATHER_REQUEST",
    zip
  };
};

export function setSearch(search) {
  return dispatch => {
    dispatch({
      type: "SET_SEARCH_STRING",
      visibilityFilter: "SHOW_FOUND",
      search
    });
  };
}
