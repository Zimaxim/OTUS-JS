import React from 'react'
import PropTypes from 'prop-types'
import { Link, Route } from 'react-router-dom';


const Location = ({ name, zip }) => (
  <Link className="w3-bar-item w3-button" to={`/zip/${zip}/0`}  >{zip} <br/> {name}</Link>
)


Location.propTypes = {
 // onClick: PropTypes.func.isRequired,
  name: PropTypes.string.isRequired
}

export default Location