import React, { Component } from "react";
import axios from "axios";

import Header from './Header'

class WeatherDisplay extends Component {
  constructor(props) {
    super(props);
    this.state = {
      weatherData: null,
      city: null
    };
    
  }
  _updateState()  {
    const zip = this.props.zip;
    const cnt = this.props.cnt || 0;
    //console.log("WeatherDisplay._updateState:: zip=" + zip);
    const URL =
      "https://api.openweathermap.org/data/2.5/forecast?q=" +
      zip +
      "&appid=b1b35bba8b434a28a0be2a3e1071ae5b&units=metric&cnt=30";

      // "https://api.openweathermap.org/data/2.5/weather?q=" +
      // zip +
      // "&appid=b1b35bba8b434a28a0be2a3e1071ae5b&units=metric";
    //"&appid=b1b35bba8b434a28a0be2a3e1071ae5b&units=imperial";

    //URL = 'https://randomuser.me/api/?results=50' ;
    axios
      .post(URL)
      .then(response => {
        const data = response.data;
        //console.log("response=", data.list[0]);
        this.setState({ weatherData: data.list[cnt], city: data.city });
      })
      .catch(error => {
        console.log(error);
      });
  }
  // componentWillReceiveProps() {
  //   this.setState({ weatherData: null });    
  //   const zip = this.props.zip;
  //   console.log("WeatherDisplay.componentWillReceiveProps:: zip=" + zip);
  //   this._updateState();
  // }
  componentDidMount() {
    this._updateState();
  }
  
  render() {
    
    //console.log("WeatherDisplay.render::zip=", this.props.zip, " state=", this.state);
    const weatherData = this.state.weatherData;
    const city = this.state.city;
    if (!weatherData) return <div>Loading</div>;
    //const weatherList = weatherData; //weatherData.weather[0];
    console.log("weatherData:", this.state.weatherData);

    const iconUrl = "http://openweathermap.org/img/w/" + weatherData.weather[0].icon + ".png";
    console.log("icon:", iconUrl);

    return (
      <div>
        <Header zip={this.props.zip} />
        <h2>{city.name}</h2>
        <p ><u>{":dt: " + weatherData.dt_txt}</u></p>
        <p>
          
          {weatherData.weather[0].main} <img src={iconUrl} alt={weatherData.weather[0].description} />{" "}
        </p>

        <p>Current: {weatherData.main.temp} °C</p>
        <p>High: {weatherData.main.temp_max} °C</p>
        <p>Low: {weatherData.main.temp_min} °C</p>
        <p>Wind Speed: {weatherData.wind.speed} m/hr</p>
      </div>
    );
  }
}
export default WeatherDisplay;
