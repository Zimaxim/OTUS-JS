import React from "react";


//import Header from "./Header";
import Navigation from "./Navigation";
import Context from "./Context";
import Footer from "./Footer";
//import AddLocation from '../containers/AddLocation'

const App = () => (
  <div>
    {/*<!-- containers -->*/}
    {/*    <AddTodo /> */}

    {/*<!-- Sidebar -->*/}

    <div className="w3-sidebar w3-grey w3-bar-block">
      <Navigation />
    </div>

    {/* <!-- Page Content --> */}
    {/* <Header />*/} 
    <div className="App-context w3-container ">
      <Context />
      <Footer />
    </div>
  </div>
);

export default App;
