import React, { Component } from "react";
import { Link, Route } from "react-router-dom";
//import Navigation from "./Navigation";

class Header extends Component {
  constructor(props) {
    super(props);
  }

  nextDay(idx = 0) {
    var xDay = new Date(new Date().setDate(new Date().getDate() + idx));
    return (
      ("" + (xDay.getDay() + 1)).padStart(2, "0") +
      "." +
      ("" + (xDay.getMonth() + 1)).padStart(2, "0")
    );
  }

  render() {
    const { username } = this.props.user || "Noname";
    const todayDate = this.nextDay(0);
    const td_1 = this.nextDay(1);
    const td_2 = this.nextDay(2);
    const td_3 = this.nextDay(3);
    const zip = this.props.zip;
    console.log("td_2", td_1, td_2, td_3, zip);

    //const { links } = this.props;
    return (
      <div className="w3-bar ">
        <Link
          className="w3-bar-item w3-button w3-mobile w3-right"
          to={`/zip/${zip}/24`}
        >
          {td_3}
        </Link>
        <Link
          className="w3-bar-item w3-button w3-mobile w3-right"
          to={`/zip/${zip}/16`}
        >
          {td_2}
        </Link>
        <Link
          className="w3-bar-item w3-button w3-mobile w3-right"
          to={`/zip/${zip}/8`}
        >
          Tomorrow
        </Link>
        <Link
          className="w3-bar-item w3-button w3-mobile w3-right"
          to={`/zip/${zip}/0`}
        >
          Now
        </Link>
      </div>
    );
  }
}

/*
      <header className="App-header">
        <h1 className="App-title"> Hello, {username}</h1>
      </header>
      */

export default Header;
