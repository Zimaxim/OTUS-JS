import React, { Component } from "react";
import { Link, Route } from "react-router-dom";

import WeatherDisplay from "./WeatherDisplay";
import AddLocation from "../containers/AddLocation";

// const Weather = ({ match }) => (
//   <div>
//     {console.log("Context.js::Weather::match.params.Zip=", match.params.Zip)}
//     <WeatherDisplay zip={match.params.Zip} />
//   </div>
// );

const Context = () => (
  <div className="w3-container">
    <Route exact path="/" render={() => <WeatherDisplay zip="141000" />} />

    <Route exact
      path="/zip/:Zip"
      component={({ match }) => (
        <div>
          {console.log(
            "Context.js:component:Weather::match.params.Zip=",
            match.params.Zip,
            "match.params.Cnt",
            match.params.Cnt
          )}
          <WeatherDisplay zip={match.params.Zip} cnt={0} />
        </div>
      )}
    />

    <Route
      path="/zip/:Zip/:Cnt"
      component={({ match }) => (
        <div>
          {console.log(
            "Context.js:component:Weather::match.params.Zip=",
            match.params.Zip,
            "match.params.Cnt",
            match.params.Cnt
          )}
          <WeatherDisplay zip={match.params.Zip} cnt={match.params.Cnt}/>
        </div>
      )}
    />

    {/*<Route path="/add" component={AddLocation} />*/}

    {/*console.log("match==", match)*/}
  </div>
);

export default Context;
