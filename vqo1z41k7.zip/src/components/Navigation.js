import React, { Component } from "react";
import SearchBar from "../containers/SearchBar";
import VisibleLocationList from '../containers/VisibleLocationList'


class Navigation extends Component {
  render() {
    const { username } = this.props.user || "Noname";
    //const { links } = this.props;
    return (
      <div className=" w3-sidebar w3-grey w3-bar-block">
        <SearchBar />
        <VisibleLocationList />  

      </div>
    );
  }
}

export default Navigation;
