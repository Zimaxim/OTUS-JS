import React, { Component } from "react";
//import PropTypes from "prop-types";

export default class SearchBar extends Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   search: null
    // };
  }
  onChangeMatch(e) {
    //this.props.setYear(+e.target.innerText);
    console.log("SearchBar:onChangeMatch: e.target.value", e.target.value);
    this.props.setSearch(e.target.value);
    //this.props.getPhotos(+e.target.innerText);
    //this.state.dispatch({ type: "SET_SEARCH_STRING", search: e.target.value });
    
  }

  render() {
    const { match } = this.props;
    //console.log("SearchBar:render: this.props", this.state);
    
    return (
      <div>
        <input 
            className="w3-input w3-border"
          type="text"
          placeholder="Search for zip.."
          onChange={::this.onChangeMatch}
        >
          {match}
        </input>
        </div>
    );
  }
}
