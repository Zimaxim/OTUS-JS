import React, { Component } from "react";

class Footer extends Component {
  render() {
    //console.log("components/Footer.js :: getState()=");
    return (
      <footer className="App-footer w3-light-grey">
        <h5>Copyright OTUS-JS (C) 2018</h5>
      </footer>
    );
  }
}

export default Footer;
