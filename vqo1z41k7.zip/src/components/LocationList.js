import React, { Component } from "react";
import PropTypes from "prop-types";
import Location from "./Location";

// const LocationList = ({ locations, onLocationClick }) => (

//   {/*console.log("components/LocationsList.js :: getState()=", locations)*/}

//   <ul>
//     {locations.map((Location, index) => (
//       <Location key={index} {...Location} onClick={() => onLocationClick(index)} />
//     ))}
//   </ul>
// )
console.log("components/LocationsList.js :: getState()=", typeof store);

const LocationList = ({ locations }) => (
  <div>
    <p>
      {console.log("components/LocationsList.js :: locations =", locations)}
    </p>
    
    {locations.map((item, idx) => (
      <Location key={idx} name={item.name} zip={item.zip} />
    ))}

    {/*
        {this.state.locations.map((place, index) => (
          <button
            className="w3-bar-item w3-button tablink"
            key={index}
            onClick={() => {
              this.setState({
                activeLocation: index,
                addLocation: 0
              });
            }}
          >
            {location.name}
          </button>
        ))} 
        */}
  </div>
);

export default LocationList;
