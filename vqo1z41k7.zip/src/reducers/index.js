import { combineReducers } from "redux";
import locations from "./locations";
import visibilityFilter from "./visibilityFilter";
import weather from "./weather";
import searchActions from "./searchActions"

const weatherApp = combineReducers({
  locations,
  visibilityFilter,
  weather,
  searchActions
});

export default weatherApp;
