const LOCATIONS = [
  { id: 1, name: "Москва", zip: "101000" },
  { id: 2, name: "Санкт-Петербург", zip: "190000" },
  { id: 3, name: "Тюмень", zip: "625000" },
  { id: 4, name: "Владивосток", zip: "690000" }
];

const initialState = {
   LOCATIONS
}
const location = (state, action) => {
  //console.log("action", action);
  switch (action.type) {
    case "ADD_LOC":
      return {
        id: action.location.id,
        name: action.location.name,
        zip: action.location.zip
      };
    // case "TOGGLE_LOC":
    //   if (state.id !== action.id) {
    //     return state;
    //   }

    //   return Object.assign({}, state, {
    //     completed: !state.completed
    //   });

    default:
      return state;
  }
};

//const locations =
export default (state = LOCATIONS, action) => {
  // console.log(
  //   "reducers/locations.js :: state =",
  //   state,
  //   " action.type=",
  //   action.type
  // );
  switch (action.type) {
    case "ADD_LOC":
      return [...state, location(undefined, action)];
    // case "TOGGLE_LOC":
    //   return state.map(t => location(t, action));
    default:
      return state;
  }
};

//export default locations;
