export default (state =[], action) => {
  switch (action.type) {
    case "GET_WEARTHER_REQUEST":
      return { ...state, weatherData: action.weatherData, fetching: true } ;
    case "GET_WEARTHER_SUCCESS":
      return { ...state, weatherData: action.weatherData, fetching: false };

    default:
      return state;
  }
};
