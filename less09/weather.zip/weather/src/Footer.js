import React, { Component } from 'react';
import './App.css';

class Footer extends Component {
  render() {
    return (
       <footer className="App-footer w3-light-grey">
			<h5>Copyright OTUS (C) 2018</h5>
		</footer>
    );
  }
}

export default Footer;